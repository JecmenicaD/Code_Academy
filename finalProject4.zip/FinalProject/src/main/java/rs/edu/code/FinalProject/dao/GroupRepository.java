package rs.edu.code.FinalProject.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import rs.edu.code.FinalProject.model.Group1;

public interface GroupRepository extends JpaRepository<Group1, Long> {

}
