package rs.edu.code.FinalProject.model;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;


import com.fasterxml.jackson.annotation.JsonIdentityInfo;

@JsonIdentityInfo(   generator = ObjectIdGenerators.PropertyGenerator.class,  property = "id")
@Entity
public class Person {

	@Id
	@GeneratedValue
	private Long id;
	@Column
	private String firstName;
	@Column
	private String lastName;
	@Column
	private String email;
	
	
	public Person() {
		super();
	}

	@ManyToMany(mappedBy = "persons")
	List<Event> events = new LinkedList<>();
	
	@ManyToMany (cascade = {CascadeType.DETACH, CascadeType.MERGE,CascadeType.PERSIST, CascadeType.REFRESH}, fetch = FetchType.EAGER )
	@JoinTable(name = "group_persons",
	joinColumns = {@JoinColumn(name = "person_id" ,referencedColumnName = "id")},
	inverseJoinColumns = {@JoinColumn(name = "group_id", referencedColumnName = "id")})
	Set<Group1> groups = new LinkedHashSet<>();

	public Person( String firstName, String lastName, String email) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Event> getEvents() {
		return events;
	}

	public void setEvents(List<Event> events) {
		this.events = events;
	}

	public Set<Group1> getGroups() {
		return groups;
	}

	public void setGroups(Set<Group1> groups) {
		this.groups = groups;
	}
	
	
	
}
