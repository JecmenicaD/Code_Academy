package rs.edu.code.FinalProject.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import rs.edu.code.FinalProject.dao.GroupRepository;
import rs.edu.code.FinalProject.model.Event;
import rs.edu.code.FinalProject.model.Group1;
import rs.edu.code.FinalProject.model.Person;

@Service
public class GroupService {
	
	@Autowired
	GroupRepository groupRepository;
	
	
	public void addGroup (String name, List<Person> persons, Set<Event> events) {
		
		Group1 group = new Group1(name, persons, events);
		
		groupRepository.save(group);
		
		
	}

	public void addPersonToGroup (Person person, Group1 group) {
		
		group.getPersons().add(person);
		groupRepository.save(group);
		
		
	}
	
	public void removePersonFromGroup (Person person, Group1 group) {
		
	   group.getPersons().remove(person);
	   groupRepository.save(group);
		
	}
	
	public Group1 getGroupById (long id) {
		Group1 group = groupRepository.getById(id);
		
		return group;
		
	}
	
	public Group1 addGroup (Group1 group) {
		return groupRepository.save(group);
	}
	
	public void deleteGroupById (long id ) {
		Group1 group = groupRepository.getById(id);
		groupRepository.delete(group);
		
		
	}
}
