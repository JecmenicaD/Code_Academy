package rs.edu.code.FinalProject.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import rs.edu.code.FinalProject.dao.PersonRepository;
import rs.edu.code.FinalProject.model.Event;
import rs.edu.code.FinalProject.model.Person;

@Service
public class ServicePerson {

	
	@Autowired
	PersonRepository repository;
	
	
	
	public Person addPerson(String firstName, String lastName, String email ) {
		
		Person person1 = new Person(firstName, lastName, email) ;
		
		repository.save(person1);
		
		return person1;
	}
	
	public Person getPersonById (long id) {
		return repository.getById(id);
	}
	
	public void removePersonById (long id) {
		repository.deleteById(id);
	}
	
	public Person addPerson1 ( Person person ) {
		return repository.save(person);
		
	}
	
	@Transactional
	public List<Event> getPersonsEvents( long personId) {
	 Person person = repository.getById(personId);
	 person.getEvents().size(); 
	 return  person.getEvents();
	}
}
