package rs.edu.code.FinalProject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import rs.edu.code.FinalProject.dao.GroupRepository;
import rs.edu.code.FinalProject.model.Group1;
import rs.edu.code.FinalProject.service.GroupService;

@RestController
@RequestMapping
public class GroupController {
	
	
	@Autowired
	GroupService groupService;
	
	
	
	@GetMapping("/groups/{id}")
	public Group1 findById (@PathVariable long id) {
		
		Group1 group = groupService.getGroupById(id);
		
		return group;
	}
	
	
	@DeleteMapping("/groups/{id}")
	public void deleteById (@PathVariable long id) {
		groupService.deleteGroupById(id);
	}
	
	@PostMapping("/groups")
	public Group1 addGroup (@RequestBody Group1 group) {
		Group1 group1 = groupService.addGroup(group);
		return group1;
		
	}
	@PutMapping("/groups/{id}")
	public Group1 updateGroup (@RequestBody Group1 group, @PathVariable long id) {
		group.setId(id);
		return groupService.addGroup(group);

	}
	
	
	}
