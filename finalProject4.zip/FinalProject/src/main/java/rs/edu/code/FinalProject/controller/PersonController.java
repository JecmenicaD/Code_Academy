package rs.edu.code.FinalProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import rs.edu.code.FinalProject.dao.PersonRepository;
import rs.edu.code.FinalProject.model.Event;
import rs.edu.code.FinalProject.model.Person;
import rs.edu.code.FinalProject.service.ServicePerson;

@RestController
@RequestMapping
public class PersonController {
	
	@Autowired
	ServicePerson servicePerson;
	
	
	@GetMapping("/persons/{id}")
	public Person getPersonById (@PathVariable long id) {
		Person person = getPersonById(id);
		
		return person;
		
	}

	@DeleteMapping("/persons/{id}")
	public void deletePersonById (@PathVariable long id) {
		servicePerson.removePersonById(id);
		
	}
		
	@PostMapping("/persons")
	public Person addPerson (@RequestBody Person person) {
		return servicePerson.addPerson1(person);
	}
	
	@GetMapping ("/persons/{id}/events")
	public List<Event> personsEvents (@PathVariable long id) {
	
		return servicePerson.getPersonsEvents(id);
		
	}
	
	@PutMapping("/persons/{id}")
	public Person updatePerson (@RequestBody Person person, @PathVariable long id ) {
		person.setId(id);
		return servicePerson.addPerson1(person);
		
	}
	
	
}
