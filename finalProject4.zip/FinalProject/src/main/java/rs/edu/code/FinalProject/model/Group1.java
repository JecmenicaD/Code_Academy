package rs.edu.code.FinalProject.model;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@JsonIdentityInfo(   generator = ObjectIdGenerators.PropertyGenerator.class,  property = "id")
@Entity
public class Group1 {

	@Id
	@GeneratedValue
	Long id;
	@Column (unique = true)
	String name;
	
	@ManyToMany(mappedBy = "groups")
	List<Person> persons = new LinkedList<>();
	
	
	@ManyToMany(mappedBy = "groups")
	Set<Event> events = new LinkedHashSet<>();


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public List<Person> getPersons() {
		return persons;
	}


	public void setPersons(List<Person> persons) {
		this.persons = persons;
	}


	public Set<Event> getEvents() {
		return events;
	}


	public void setEvents(Set<Event> events) {
		this.events = events;
	}


	public Group1(String name, List<Person> persons, Set<Event> events) {
		super();
		this.name = name;
		this.persons = persons;
		this.events = events;
	}


	public Group1() {
		super();
	}
	
	
	
}
