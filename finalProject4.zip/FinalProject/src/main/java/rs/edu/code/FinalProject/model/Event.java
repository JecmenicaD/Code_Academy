package rs.edu.code.FinalProject.model;

import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;


@JsonIdentityInfo(   generator = ObjectIdGenerators.PropertyGenerator.class,  property = "id")
@Entity
public class Event {

	
	@Id
	@GeneratedValue
	private Long id;
	@Column(unique = true)
	private String title;
	@Column
	private String description;
	@ManyToOne(cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH},fetch = FetchType.EAGER)
	@JoinColumn(name = "category")
	Category category;
	@Column
	private LocalDateTime date;
	@Column
	private String location;
	@Column
	private Long capacity;
	@Column
	private EventStatus status;
	
	@LazyCollection(LazyCollectionOption.FALSE)
	@ManyToMany (cascade = {CascadeType.DETACH, CascadeType.MERGE,CascadeType.PERSIST, CascadeType.REFRESH})
	@JoinTable(name = "events_persons",
	joinColumns = {@JoinColumn(name = "event_id" ,referencedColumnName = "id")},
	inverseJoinColumns = {@JoinColumn(name = "person_id", referencedColumnName = "id")})
	List<Person> persons = new LinkedList<>();
	@LazyCollection(LazyCollectionOption.FALSE)
	@ManyToMany(cascade = {CascadeType.DETACH, CascadeType.MERGE,CascadeType.PERSIST, CascadeType.REFRESH} )
	@JoinTable(name = "group_events",
	joinColumns = {@JoinColumn(name = "event_id" ,referencedColumnName = "id")},
	inverseJoinColumns = {@JoinColumn(name = "group_id", referencedColumnName = "id")})
	List<Group1> groups = new LinkedList<>();
	
	public void addPersonToEvent(Person person) {
		if (persons.size() > capacity) {
			throw new IllegalArgumentException("Event je pun");
		}
			else {
				persons.add(person); 
			}
	}

	

	public void addGroupToEvent(Group1 group)  {
		
		if (group.persons.size() > capacity) {
			throw new IllegalArgumentException("Vise ljudi od planiranog");
		}
		else {
			persons.addAll(group.persons);
		}
		
		
		
	}
	
	public List<Group1> getGroups() {
		return groups;
	}

	public void setGroups(List<Group1> groups) {
		this.groups = groups;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public Category getCategory() {
		return category;
	}
	
	
	public void setCategory(Category category) {
		this.category = category;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Long getCapacity() {
		return capacity;
	}

	public void setCapacity(Long capacity) {
		this.capacity = capacity;
	}

	public EventStatus getStatus() {
		return status;
	}

	public void setStatus(EventStatus status) {
		this.status = status;
	}

	public List<Person> getPersons() {
		return persons;
	}

	public void setPersons(List<Person> persons) {
		this.persons = persons;
	}

	public Long getId() {
		return id;
	}



	public Event(String title, String description, Category category, LocalDateTime date, String location,
			Long capacity, EventStatus status) {
		
		this.title = title;
		this.description = description;
		this.category = category;
		this.date = date;
		this.location = location;
		this.capacity = capacity;
		this.status = status;
		
	}



	public Event() {
	
	}
	
	
	
	
}

	
		
