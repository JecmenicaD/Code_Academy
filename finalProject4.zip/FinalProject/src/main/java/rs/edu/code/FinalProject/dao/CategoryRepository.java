package rs.edu.code.FinalProject.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import rs.edu.code.FinalProject.model.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {

}
