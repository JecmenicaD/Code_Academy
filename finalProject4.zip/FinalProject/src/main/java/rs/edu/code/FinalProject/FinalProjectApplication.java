package rs.edu.code.FinalProject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import rs.edu.code.FinalProject.model.Category;
import rs.edu.code.FinalProject.model.Event;
import rs.edu.code.FinalProject.model.EventStatus;
import rs.edu.code.FinalProject.model.Person;
import rs.edu.code.FinalProject.service.ServiceEvent;
import rs.edu.code.FinalProject.service.ServicePerson;


@SpringBootApplication
public class FinalProjectApplication implements ApplicationRunner{

	@Autowired
	ServicePerson servicePerson;
	
	@Autowired
	ServiceEvent serviceEvent;
	
	public static void main(String[] args) {
		SpringApplication.run(FinalProjectApplication.class, args);
	
		
	
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		
		System.out.println("Dodajem u Person");	
		
		Person milan = new Person("Milan", "Novakovic", "novakovicm@gmail.com");
		Person jovan = new Person("Jovan", "Milanovic", "milanovicj@gmail.com");
		
		
		servicePerson.addPerson("Dusan", "Jecmenica", "jecmenica.dusan@gmail.com");
		
		
		System.out.println("Dodajem u Event");
		
		Category category = new Category("Edukativni");	
		
		LocalDate thisDate = LocalDate.of(2022, 2, 15);
		LocalDateTime javakurs = thisDate.atTime(17, 30);
		
		EventStatus status = EventStatus.COMPLETED;
				
		Event event = new Event("Java kurs", "Skola Java programiranja", category, javakurs, "Savski trg 8", (long) 10, status);
		
		
		
		event = serviceEvent.addEvent(event);
		
		event = serviceEvent.addPersonToEvent(event, jovan);
		event = serviceEvent.addPersonToEvent(event, milan);
		
	
	}

	
	
	
	
}
