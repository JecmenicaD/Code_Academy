package rs.edu.code.FinalProject.model;

public enum EventStatus {

	SCHEDULED,
	COMPLETED,
	CANCELED
	
}
