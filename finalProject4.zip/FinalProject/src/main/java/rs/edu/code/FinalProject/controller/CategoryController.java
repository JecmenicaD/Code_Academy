package rs.edu.code.FinalProject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import rs.edu.code.FinalProject.dao.CategoryRepository;
import rs.edu.code.FinalProject.model.Category;
import rs.edu.code.FinalProject.model.Group1;
import rs.edu.code.FinalProject.service.CategoryService;

@RestController
public class CategoryController {
	
	@Autowired
	CategoryService categoryService;
	
	
	@PostMapping("/categories")
	public Category addCategory (@RequestBody Category category) {
		
		return categoryService.addCategory(category);
	}
	
	@GetMapping("/categories/{id}") 
	public Category getCategoryById (@PathVariable long id) {
		return categoryService.getCategoryById(id);
	}
	
	@PutMapping("/categories/{id}")
	public Category updateCategory (@RequestBody Category category, @PathVariable long id) {
		category.setId(id);
		return categoryService.addCategory(category);
	}
	
	@DeleteMapping ("/categories")
	public void removeCategoryById (@PathVariable long id) {
		categoryService.removeCategoryById(id);
	}
	

}
