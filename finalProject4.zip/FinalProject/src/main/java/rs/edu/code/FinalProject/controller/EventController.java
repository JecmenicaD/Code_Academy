package rs.edu.code.FinalProject.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import rs.edu.code.FinalProject.dao.EventRepository;
import rs.edu.code.FinalProject.model.Category;
import rs.edu.code.FinalProject.model.Event;
import rs.edu.code.FinalProject.service.ServiceEvent;

@RestController
@RequestMapping
public class EventController {
	
	
	@Autowired
	ServiceEvent eventService;
	
	
	@GetMapping ("/events/{id}")
	public Event getEventById(@PathVariable long id) {
		Event event = eventService.getEventById(id);
		return event;
		
	}
	
	@DeleteMapping("/events/{id}")
	public void deleteById(@PathVariable long id) {
		eventService.removeEventById(id);
		
		
	}

	@PostMapping("/events")
	public Event addEvent (@RequestBody Event event) {
		return eventService.addEvent(event);	
	}
	
	@PutMapping("/events/{id}")
	public Event updateEvent (@RequestBody Event event, @PathVariable long id) {
		event.setId(id);
		
		return eventService.addEvent(event);
		
		
	}
	
	@GetMapping ("/events/byCategory/{category}")
	public List<Event> getEventsByCategory (@PathVariable String category)) {
		return eventService.getEventsByCategory(category);
	}
	
	@GetMapping ("/events/{date}") 
	public List<Event> getEventsByDate (@PathVariable @DateTimeFormat(iso = ISO.DATE) LocalDate date) {
		
		LocalDateTime date1 = date.atStartOfDay();
		
		return eventService.getEventsByDate(date1 , date1.plusDays(1));
	}
}
