package rs.edu.code.FinalProject.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import rs.edu.code.FinalProject.dao.EventRepository;
import rs.edu.code.FinalProject.model.Category;
import rs.edu.code.FinalProject.model.Event;
import rs.edu.code.FinalProject.model.EventStatus;
import rs.edu.code.FinalProject.model.Group1;
import rs.edu.code.FinalProject.model.Person;

@Service
public class ServiceEvent {

	@Autowired
	EventRepository eventRepository;
	
	
	
	public void addEvent(String title, String description, Category category, LocalDateTime date, long capacity,EventStatus status, List<Person> persons  )   {
		
		Event event = new Event();
		event.setTitle(title);
		event.setDescription(description);
		event.setCategory(category);
		event.setDate(date);
		event.setCapacity(capacity);
		event.setStatus(status);
		event.setPersons(persons);
		event.getPersons().forEach(p -> p.getEvents().add(event));
		
		
		
		Event savedEvent = eventRepository.save(event);
				
	}
	
	public Event addPersonToEvent (Event event, Person person) throws IllegalArgumentException {
		
		
		if (event.getPersons().size() < event.getCapacity()) {
			
			event.getPersons().add(person);
			
			person.getEvents().add(event);
			
			return eventRepository.save(event);
		}

		else throw new IllegalArgumentException("Kapacitet je ispunjen");
		
		
	}



	public Event addEvent(Event event) {
		
		return eventRepository.save(event);
	}
	
	public Event getEventById (long id) {
		
		return eventRepository.getById(id);
	}
	
	
	public void removeEventById (long id) {
	
		eventRepository.deleteById(id);
		}
	
	public List<Event> getByDate(LocalDate date) {
	   
		return eventRepository.getEventsByDateBetween(date.atStartOfDay(), date.atTime(23, 59, 59));
		
		
	}
	
	
	public void addGroupToEvent(Group1 group1, Event event) {
		
		if ((event.getPersons().size() + group1.getPersons().size()) <= event.getCapacity()) {
			
			group1.getPersons().forEach(person -> person.getEvents().add(event));
			group1.getPersons().forEach( person -> addPersonToEvent(event, person));		
			
			
		}
		
		else throw new IllegalArgumentException("Nema dovoljno mesta da se doda grupa");
	}
		
	public List<Event> getEventsByCategory (String categoryName) {
		return	eventRepository.getEventsByCategory(categoryName);
		

			
		}
		
	public List<Event> getEventsByDate (LocalDateTime start, LocalDateTime end) {
			return eventRepository.getEventsByDateBetween(start, end);
		
	}
	}

