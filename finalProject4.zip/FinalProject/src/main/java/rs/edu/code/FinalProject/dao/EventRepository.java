package rs.edu.code.FinalProject.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import rs.edu.code.FinalProject.model.Category;
import rs.edu.code.FinalProject.model.Event;
import rs.edu.code.FinalProject.model.Person;

public interface EventRepository extends JpaRepository<Event, Long> {

	
	@Query("SELECT e FROM Event AS e WHERE e.category.name = ?1") 
	List<Event> getEventsByCategory(String categoryName);

	
	@Query
	List<Event> getEventsByDateBetween(LocalDateTime start, LocalDateTime end);
	
	@Query(value = "SELECT e FROM Event AS e WHERE ?1 MEMBER OF e.persons", nativeQuery = false)
	List<Event> allEventsOfPerson (Person person);
}

