package rs.edu.code.FinalProject.model;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@JsonIdentityInfo(   generator = ObjectIdGenerators.PropertyGenerator.class,  property = "id")
@Entity
public class Category {

	
	@Id
	@GeneratedValue
	private long id;
	
	@Column
	private String name;

	//	@OneToMany(cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST,CascadeType.REFRESH}, orphanRemoval = false)
	// @JoinColumn(name = "category")
	// List<Event> eventsInCategory = new LinkedList<>();
	
	
	public Category(String name) {
		this.name = name;
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Category() {
		super();
	}


//	public List<Event> getEventsInCategory() {
//		return eventsInCategory;
//	}
//
//
//	public void setEventsInCategory(List<Event> eventsInCategory) {
//		this.eventsInCategory = eventsInCategory;
//	}
//	

	
	
}
