package rs.edu.code.FinalProject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import rs.edu.code.FinalProject.dao.CategoryRepository;
import rs.edu.code.FinalProject.model.Category;

@Service
public class CategoryService {

	
	@Autowired
	CategoryRepository categoryRepository;
	
	
	
	public Category getCategoryById (long id) {
		return categoryRepository.getById(id);
		
	}
	
	public Category addCategory (Category category) {
		return categoryRepository.save(category);
		
	}
	
	public Category updateCategory (Category category, long id) {
		
		category.setId(id);
		return categoryRepository.save(category);
	}
	public void removeCategoryById (long id) {
		
		categoryRepository.deleteById(id);
	}
	
}
